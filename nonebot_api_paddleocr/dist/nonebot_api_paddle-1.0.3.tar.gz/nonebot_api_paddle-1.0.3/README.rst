**Features**
Supports use in group chat and private chat
Supports continuous conversation
Supports Chinese, English and characters

**Usage**
Web API recognition: send /apiocr, only support photos of Chinese, English and digital punctuation, cannot switch languages. Send /end to end the current user conversation, and users do not affect each other.